﻿using JobPortal_Capstone.Models;

namespace JobPortal_Capstone.IServices
{
    public interface IJobApplicationService
    {
        IEnumerable<JobApplications> GetAllJobApplications();
        JobApplications GetJobApplicationById(int id);
        JobApplications Apply(JobApplications jobApplication);
        IEnumerable<JobApplications> GetJobApplicationByJobListingId(int jobListingId);
        void DeleteJobApplication(int id);
    }
}
