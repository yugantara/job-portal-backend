﻿using JobPortal_Capstone.Models;

namespace JobPortal_Capstone.IServices
{
    public interface IJobListingService
    {
        public IEnumerable<JobListings> GetJobListings();
        JobListings GetJobById(int id);
        JobListings PostJob(JobListings jobListing);
        void UpdateJobDetails(JobListings jobListing);
        void DeleteJob(int id);
    }
}
