﻿namespace JobPortal_Capstone.IServices
{
    public interface ISubscriptionService
    {
    }
}
