﻿using JobPortal_Capstone.Data;
using JobPortal_Capstone.IRepositories;
using JobPortal_Capstone.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;

namespace JobPortal_Capstone.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly AppDbContext _context;
        public UserRepository(AppDbContext context)
        {
            _context = context;
        }
        public IEnumerable<Users> GetAllUsers()
        {
            return _context.Users.ToList();
        }
        public Users GetUserById(int id)
        {
            return _context.Users.Find(id);
        }

        public Users GetUserByUsername(string username)
        {
            return _context.Users.FirstOrDefault(u => u.Username == username);
        }
        public Users RegisterUser(Users user)
        {
            if (_context.Users.Where(u => u.Username == user.Username).Any())
            {
                throw new Exception("The username already exists. Please try to register with other username.");
            }
            if (_context.Users.Where(u => u.Email == user.Email).Any())
            {
                throw new Exception("The email is already registered. Please try to register with another email.");
            }
            try
            {
                user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);

                if (user.JobSeeker != null)
                {
                    user.JobSeekerId = _context.JobSeeker.ToList().Count > 0 ? _context.JobSeeker.Max(j => j.ID) + 1 : 1;
                    user.JobSeeker.ID = _context.JobSeeker.ToList().Count > 0 ? _context.JobSeeker.Max(j => j.ID) + 1 : 1;
                    _context.JobSeeker.Add(user.JobSeeker);
                    _context.SaveChanges();
                }
                if (user.Employer != null)
                {
                    user.EmployerId = _context.Employer.ToList().Count > 0 ? _context.Employer.Max(j => j.ID) + 1 : 1;
                    user.Employer.ID = _context.Employer.ToList().Count > 0 ? _context.Employer.Max(j => j.ID) + 1 : 1;
                    _context.Employer.Add(user.Employer);
                    _context.SaveChanges();
                }
                if (user.Admin != null)
                {
                    user.AdminId = _context.Admin.ToList().Count > 0 ? _context.Admin.Max(j => j.ID) + 1 : 1;
                    user.Admin.ID = _context.Admin.ToList().Count > 0 ? _context.Admin.Max(j => j.ID) + 1 : 1;
                    _context.Admin.Add(user.Admin);
                    _context.SaveChanges();
                }
                _context.Users.Add(user);
                _context.SaveChanges();
                return user;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        public Users LoginUser(string username, string password)
        {
            Users user = _context.Users.SingleOrDefault(u => u.Username == username);

            if (user == null)
                throw new Exception("Invalid username.");

            // Verify the password
            bool isValidPassword = BCrypt.Net.BCrypt.Verify(password, user.Password);

            if (isValidPassword)
            {
                return user;
            }
            else
            {
                throw new Exception("User Login failed due to incorrect password");
            };
        }
        public void UpdateUser(Users user)
        {
            Users usr = _context.Users.Find(user.Id);

            if (user.JobSeeker != null && usr.JobSeekerId != user.JobSeekerId)
            {
                throw new Exception("If you want to update the Job Seeker profile, please enter a valid Job Seeker Id.");
            }
            if (user.Employer != null && usr.EmployerId != user.EmployerId)
            {
                throw new Exception("If you want to update the Employer profile, please enter a valid Employer Id.");
            }
            if (user.Admin != null && usr.AdminId != user.AdminId)
            {
                throw new Exception("If you want to update the Admin profile, please enter a valid Admin Id.");
            }

            // Verify the password
            bool isValidPassword = BCrypt.Net.BCrypt.Verify(user.Password, usr.Password);

            if (isValidPassword)
            {
                usr.Username = string.IsNullOrEmpty(user.Username) ? usr.Username : user.Username;
                usr.Email = string.IsNullOrEmpty(user.Email) ? usr.Email : user.Email;
                usr.FullName = string.IsNullOrEmpty(user.FullName) ? usr.FullName : user.FullName;
                usr.ContactNumber = string.IsNullOrEmpty(user.ContactNumber) ? usr.ContactNumber : user.ContactNumber;
                usr.Bio = string.IsNullOrEmpty(user.Bio) ? usr.Bio : user.Bio;
                if (user.Admin != null)
                {
                    Admin admin = _context.Admin.Find(usr.AdminId);
                    admin.Department = user.Admin.Department;
                    admin.Role = user.Admin.Role;
                }
                if (user.Employer != null)
                {
                    Employer employer = _context.Employer.Find(usr.EmployerId);
                    employer.CompanyName = user.Employer.CompanyName;
                    employer.CompanySize = user.Employer.CompanySize;
                    employer.Industry = user.Employer.Industry;
                    employer.Website = user.Employer.Website;
                }
                if (user.JobSeeker != null)
                {
                    JobSeeker seeker = _context.JobSeeker.Find(usr.JobSeekerId);
                    seeker.EducationLevel = user.JobSeeker.EducationLevel;
                    seeker.Skills = user.JobSeeker.Skills;
                    seeker.ExperienceYears = user.JobSeeker.ExperienceYears;
                    seeker.ResumeFilePath = user.JobSeeker.ResumeFilePath;
                }

                _context.SaveChanges();
            }
            else
            {
                throw new Exception("Incorrect password.");
            }
        }

        public void DeleteUser(int id)
        {
            var userToDelete = _context.Users.Find(id);
            if (userToDelete != null)
            {
                if (userToDelete.JobSeekerId != null)
                {
                    var seeker = _context.JobSeeker.Find(userToDelete.JobSeekerId);
                    _context.JobSeeker.Remove(seeker);
                }
                if (userToDelete.EmployerId != null)
                {
                    var employer = _context.Employer.Find(userToDelete.EmployerId);
                    _context.Employer.Remove(employer);
                }
                if (userToDelete.Admin != null)
                {
                    var admin = _context.Admin.Find(userToDelete.AdminId);
                    _context.Admin.Remove(admin);
                }
                _context.Users.Remove(userToDelete);
                _context.SaveChanges();
            }
        }
    }
}
