﻿using JobPortal_Capstone.Data;
using JobPortal_Capstone.IRepositories;
using JobPortal_Capstone.Models;
using Microsoft.IdentityModel.Tokens;

namespace JobPortal_Capstone.Repositories
{
    public class JobListingRepository : IJobListingRepository
    {
        private readonly AppDbContext _context;

        public JobListingRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<JobListings> GetJobListings()
        {
            return _context.JobListings;
        }

        public JobListings GetJobById(int id)
        {
            return _context.JobListings.Find(id);
        }

        public JobListings PostJob(JobListings jobListing)
        {
            _context.JobListings.Add(jobListing);
            _context.SaveChanges();
            return jobListing;
        }

        public void Update(JobListings jobListing)
        {
            var existingJobListing = _context.JobListings.FirstOrDefault(j => j.Id == jobListing.Id);
            if (existingJobListing != null)
            {
                existingJobListing.Title = string.IsNullOrEmpty(jobListing.Title) ? existingJobListing.Title : jobListing.Title;
                existingJobListing.Description = string.IsNullOrEmpty(jobListing.Description) ? existingJobListing.Description : jobListing.Description;
                existingJobListing.Category = string.IsNullOrEmpty(jobListing.Category) ? existingJobListing.Category : jobListing.Category;
                existingJobListing.Location = string.IsNullOrEmpty(jobListing.Location) ? existingJobListing.Location : jobListing.Location;
                existingJobListing.Salary = jobListing.Salary;
                existingJobListing.DatePosted = jobListing.DatePosted;
                _context.SaveChanges();
            }
            else
            {
                throw new Exception("Job does not exist with this Id.");
            }
        }

        public void Delete(int id)
        {
            var jobListing = _context.JobListings.FirstOrDefault(j => j.Id == id);
            if (jobListing != null)
            {
                _context.JobListings.Remove(jobListing);
                _context.SaveChanges();
            }
            else
            {
                throw new Exception("User does not exist!");
            }

        }
    }
}
