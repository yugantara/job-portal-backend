﻿using JobPortal_Capstone.Data;
using JobPortal_Capstone.IRepositories;
using JobPortal_Capstone.Models;

namespace JobPortal_Capstone.Repositories
{
    public class JobApplicationRepository : IJobApplicationRepository
    {
        private readonly AppDbContext _context;
        public JobApplicationRepository(AppDbContext context)
        {
            _context = context;
        }
        public JobApplications Apply(JobApplications jobApplication)
        {
            _context.JobApplications.Add(jobApplication);
            _context.SaveChanges();
            return jobApplication;
        }

        public JobApplications GetJobApplicationById(int id)
        {
            return _context.JobApplications.Find(id);
        }
        public IEnumerable<JobApplications> GetAllJobApplications()
        {
            return _context.JobApplications.ToList();
        }

        public IEnumerable<JobApplications> GetByJobId(int jobListingId)
        {
            return _context.JobApplications.Where(j => j.JobId == jobListingId);
        }

        public void DeleteJobApplication(int id)
        {
            var jobApplication = _context.JobApplications.Find(id);
            if (jobApplication != null)
            {
                _context.JobApplications.Remove(jobApplication);
                _context.SaveChanges();
            }
        }
    }
}
