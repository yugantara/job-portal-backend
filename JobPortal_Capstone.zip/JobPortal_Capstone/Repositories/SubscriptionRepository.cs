﻿using JobPortal_Capstone.IRepositories;

namespace JobPortal_Capstone.Repositories
{
    public class SubscriptionRepository : ISubscriptionRepository
    {
    }
}
