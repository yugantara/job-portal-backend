﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal_Capstone.Models
{
    public class Users
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        [EmailAddress]
        public string Email { get; set; }
        public string FullName { get; set; }

        [MaxLength(20)]
        public string ContactNumber { get; set; }

        public string? Bio { get; set; }

        // Foreign key references for Job Seeker, Employer, and Admin
        public int? JobSeekerId { get; set; }
        public int? EmployerId { get; set; }
        public int? AdminId { get; set; }

        [ForeignKey("AdminId")]
        public Admin? Admin { get; set; }

        [ForeignKey("EmployerId")]
        public Employer? Employer { get; set; }

        [ForeignKey("JobSeekerId")]
        public JobSeeker? JobSeeker { get; set; }
    }
}

