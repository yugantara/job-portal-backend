﻿namespace JobPortal_Capstone.Models
{
    public class Employer
    {
        public int ID { get; set; }
        public string CompanyName { get; set; }
        public int CompanySize { get; set; }
        public string Industry { get; set; }
        public string Website { get; set; }
    }
}
