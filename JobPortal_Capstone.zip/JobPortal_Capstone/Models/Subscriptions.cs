﻿namespace JobPortal_Capstone.Models
{
    public class Subscriptions
    {
        public int Id { get; set; }

        public int EmployerId { get; set; } // Foreign Key referencing User.Id

        public SubscriptionType SubscriptionType { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public bool IsActive { get; set; }
    }

    public enum SubscriptionType
    {
        Basic,
        Standard,
        Premium
    }
}

