﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal_Capstone.Models
{
    public class JobCategory
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string Name { get; set; }
    }
}
