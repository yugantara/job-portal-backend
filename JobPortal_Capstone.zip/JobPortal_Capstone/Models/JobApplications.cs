﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal_Capstone.Models
{
    public class JobApplications
    {
        public int Id { get; set; }

        [Required]
        public int JobId { get; set; } // Foreign Key referencing JobListing.Id

        [Required]
        public int JobSeekerId { get; set; } // Foreign Key referencing User.Id
        public ApplicationStatus Status { get; set; }
        public DateTime DateApplied { get; set; }
        public string? CoverLetter { get; set; }
        public string ResumeFile { get; set; }  
    }

    public enum ApplicationStatus
    {
        Pending,
        Accepted,
        Rejected
    }
}

