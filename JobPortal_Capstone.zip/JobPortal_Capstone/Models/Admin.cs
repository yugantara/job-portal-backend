﻿namespace JobPortal_Capstone.Models
{
    public class Admin
    {
        public int ID { get; set; }
        public string Department { get; set; }
        public string Role { get; set; }
    }
}
