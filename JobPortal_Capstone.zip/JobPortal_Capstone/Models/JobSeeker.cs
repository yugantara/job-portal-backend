﻿namespace JobPortal_Capstone.Models
{
    public class JobSeeker
    {
        public int ID { get; set; }
        public string EducationLevel { get; set; }
        public string Skills { get; set; }
        public int ExperienceYears { get; set; }
        public string ResumeFilePath { get; set; }
    }
}
