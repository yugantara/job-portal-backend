﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal_Capstone.Models
{
    public class JobListings
    {
        public int Id { get; set; }

        public int EmployerId { get; set; } 

        public string Title { get; set; }

        public string Description { get; set; }

        public string Category { get; set; }

        public string Location { get; set; }

        public decimal Salary { get; set; }

        public DateTime DatePosted { get; set; }
    }
}
