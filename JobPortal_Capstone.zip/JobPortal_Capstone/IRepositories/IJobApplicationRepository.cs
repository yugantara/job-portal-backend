﻿using JobPortal_Capstone.Models;

namespace JobPortal_Capstone.IRepositories
{
    public interface IJobApplicationRepository
    {
        IEnumerable<JobApplications> GetAllJobApplications();
        JobApplications GetJobApplicationById(int id);
        IEnumerable<JobApplications> GetByJobId(int jobListingId);
        JobApplications Apply(JobApplications jobApplication);
        void DeleteJobApplication(int id);

    }
}
