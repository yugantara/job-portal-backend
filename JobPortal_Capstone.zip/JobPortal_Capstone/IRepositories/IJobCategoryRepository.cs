﻿namespace JobPortal_Capstone.IRepositories
{
    public interface IJobCategoryRepository
    {
    }
}
