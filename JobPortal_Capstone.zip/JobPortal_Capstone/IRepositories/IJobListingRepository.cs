﻿using JobPortal_Capstone.Models;

namespace JobPortal_Capstone.IRepositories
{
    public interface IJobListingRepository
    {
        IEnumerable<JobListings> GetJobListings();
        public JobListings GetJobById(int id);
        public JobListings PostJob(JobListings jobListing);
        public void Update(JobListings jobListing);
        public void Delete(int id);

    }
}
