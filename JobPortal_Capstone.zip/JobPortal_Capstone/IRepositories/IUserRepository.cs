﻿using JobPortal_Capstone.Models;

namespace JobPortal_Capstone.IRepositories
{
    public interface IUserRepository
    {
        IEnumerable<Users> GetAllUsers();
        Users GetUserById(int id);
        Users GetUserByUsername(string username);
        Users RegisterUser(Users user);
        Users LoginUser(string username, string password);
        void UpdateUser(Users user);
        void DeleteUser(int id);        
        
    }
}
