﻿namespace JobPortal_Capstone.IRepositories
{
    public interface ISubscriptionRepository
    {
    }
}
