﻿using JobPortal_Capstone.IServices;

namespace JobPortal_Capstone.Services
{
    public class SubscriptionService : ISubscriptionService
    {

    }
}
