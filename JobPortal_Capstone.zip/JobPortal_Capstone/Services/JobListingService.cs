﻿using JobPortal_Capstone.IRepositories;
using JobPortal_Capstone.IServices;
using JobPortal_Capstone.Models;

namespace JobPortal_Capstone.Services
{
    public class JobListingService : IJobListingService
    {
        private readonly IJobListingRepository _jobListingRepository;

        public JobListingService(IJobListingRepository jobListingRepository)
        {
            _jobListingRepository = jobListingRepository;
        }

        public IEnumerable<JobListings> GetJobListings()
        {
            return _jobListingRepository.GetJobListings();
        }

        public JobListings GetJobById(int id)
        {
            return _jobListingRepository.GetJobById(id);
        }

        public JobListings PostJob(JobListings jobListing)
        {
            if (jobListing == null)
                throw new Exception("Cannot post a job with no details");
            if (jobListing.EmployerId == 0)
                throw new Exception("Employer Id is mandatory to post a job.");
            if (string.IsNullOrEmpty(jobListing.Title))
                throw new Exception("Cannot post a job without title");
            if (string.IsNullOrEmpty(jobListing.Description))
                throw new Exception("Cannot post a job without description");
            if (string.IsNullOrEmpty(jobListing.Category))
                throw new Exception("Please enter a valid job category");
            if (string.IsNullOrEmpty(jobListing.Location))
                throw new Exception("Cannot post a job without location");
     
            jobListing.DatePosted = DateTime.Now; // Set the posted date to current date/time

            return _jobListingRepository.PostJob(jobListing);
        }

        public void UpdateJobDetails(JobListings jobListing)
        {
            if (jobListing == null)
                throw new Exception("Cannot update a job with no details");

            _jobListingRepository.Update(jobListing);
        }

        public void DeleteJob(int id)
        {
            _jobListingRepository.Delete(id);
        }
    }
}
