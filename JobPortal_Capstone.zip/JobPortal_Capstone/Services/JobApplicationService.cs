﻿using JobPortal_Capstone.IRepositories;
using JobPortal_Capstone.IServices;
using JobPortal_Capstone.Models;
using JobPortal_Capstone.Repositories;

namespace JobPortal_Capstone.Services
{
    public class JobApplicationService : IJobApplicationService
    {
        private readonly IJobApplicationRepository _jobApplicationRepository;

        public JobApplicationService(IJobApplicationRepository jobApplicationRepository)
        {
            _jobApplicationRepository = jobApplicationRepository;
        }

        public IEnumerable<JobApplications> GetAllJobApplications()
        {
            return _jobApplicationRepository.GetAllJobApplications();
        }

        public JobApplications GetJobApplicationById(int id)
        {
            return _jobApplicationRepository.GetJobApplicationById(id);
        }
        public JobApplications Apply(JobApplications jobApplication)
        {
            // Validate job application data as needed

            return _jobApplicationRepository.Apply(jobApplication);
        }

        public IEnumerable<JobApplications> GetJobApplicationByJobListingId(int jobListingId)
        {
            return _jobApplicationRepository.GetByJobId(jobListingId);
        }

        public void DeleteJobApplication(int id)
        {
            _jobApplicationRepository.DeleteJobApplication(id);
        }
    }
}
