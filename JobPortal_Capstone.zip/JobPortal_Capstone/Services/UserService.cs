﻿using JobPortal_Capstone.IRepositories;
using JobPortal_Capstone.IServices;
using JobPortal_Capstone.Models;
using Microsoft.IdentityModel.Tokens;
using System.Text.RegularExpressions;

namespace JobPortal_Capstone.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public IEnumerable<Users> GetAllUsers()
        {
            return _userRepository.GetAllUsers();
        }

        public Users GetUserById(int id)
        {
            return _userRepository.GetUserById(id);
        }

        public Users GetUserByUsername(string username)
        {
            return _userRepository.GetUserByUsername(username);
        }

        public Users RegisterUser(Users user)
        {
            if (user.Username.IsNullOrEmpty())
            {
                throw new Exception("Username can not be null or empty. Please enter a valid Username.");
            }
            if (user.Password.IsNullOrEmpty())
            {
                throw new Exception("Password can not be null or empty. Please enter a valid Password.");
            }
            if (user.Email.IsNullOrEmpty())
            {
                throw new Exception("Email can not be null or empty. Please enter a valid Email.");
            }
            if (user.FullName.IsNullOrEmpty())
            {
                throw new Exception("FullName can not be null or empty. Please enter your FullName.");
            }
            var regex = new Regex(@"^\+?(\d[\d-. ]+)?(\([\d-. ]+\))?[\d-. ]+\d$");
            if (!regex.IsMatch(user.ContactNumber))
            {
                throw new Exception("Invalid contact number format.. Please enter a valid Contact Number.");
            }
            if ((user.JobSeekerId == null && user.EmployerId == null && user.AdminId == null) ||
            (user.JobSeekerId != null && user.EmployerId != null && user.AdminId != null))
            {
                throw new Exception("Exactly one of JobSeekerId, EmployerId, or AdminId must have a value and the others must be null.");
            }
            if ((user.JobSeekerId != null && user.EmployerId == null && user.AdminId == null) && (user.JobSeeker == null || user.Employer != null || user.Admin != null))
            {
                throw new Exception("You have entered JobSeekerId so please enter JobSeeker Details and Leave Employer and Admin Details null.");
            }
            if ((user.JobSeekerId == null && user.EmployerId != null && user.AdminId == null) && (user.JobSeeker != null || user.Employer == null || user.Admin != null))
            {
                throw new Exception("You have entered EmployerId so please enter Employer Details and Leave JobSeeker and Admin Details null.");
            }
            if ((user.JobSeekerId == null && user.EmployerId == null && user.AdminId != null) && (user.JobSeeker != null || user.Employer != null || user.Admin == null))
            {
                throw new Exception("You have entered AdminId so please enter Admin Details and Leave JobSeeker and Employer Details null.");
            }
            return _userRepository.RegisterUser(user);
        }

        public void UpdateUser(Users user)
        {
            if (user.Password.IsNullOrEmpty())
            {
                throw new Exception("You need to enter a valid and correct Password to update your profile.");
            }
            var regex = new Regex(@"^\+?(\d[\d-. ]+)?(\([\d-. ]+\))?[\d-. ]+\d$");
            if (!regex.IsMatch(user.ContactNumber))
            {
                throw new Exception("Invalid contact number format.. Please enter a valid Contact Number.");
            }
            if ((user.JobSeekerId == null && user.EmployerId == null && user.AdminId == null) ||
            (user.JobSeekerId != null && user.EmployerId != null && user.AdminId != null))
            {
                throw new Exception("Exactly one of JobSeekerId, EmployerId, or AdminId can have a value to update the profile and the others must be null.");
            }
            if ((user.JobSeekerId != null && user.EmployerId == null && user.AdminId == null) && (user.JobSeeker == null || user.Employer != null || user.Admin != null))
            {
                throw new Exception("You have entered JobSeekerId so please enter JobSeeker Details and Leave Employer and Admin Details null.");
            }
            if ((user.JobSeekerId == null && user.EmployerId != null && user.AdminId == null) && (user.JobSeeker != null || user.Employer == null || user.Admin != null))
            {
                throw new Exception("You have entered EmployerId so please enter Employer Details and Leave JobSeeker and Admin Details null.");
            }
            if ((user.JobSeekerId == null && user.EmployerId == null && user.AdminId != null) && (user.JobSeeker != null || user.Employer != null || user.Admin == null))
            {
                throw new Exception("You have entered AdminId so please enter Admin Details and Leave JobSeeker and Employer Details null.");
            }
            _userRepository.UpdateUser(user);
        }

        public void DeleteUser(int id)
        {
            _userRepository.DeleteUser(id);
        }

        public Users LoginUser(string username, string password)
        {
            return _userRepository.LoginUser(username, password);
        }

    }
}
