﻿using JobPortal_Capstone.Models;
using Microsoft.EntityFrameworkCore;

namespace JobPortal_Capstone.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Users> Users { get; set; }
        public DbSet<JobListings> JobListings { get; set; }
        public DbSet<JobApplications> JobApplications { get; set; }
        public DbSet<JobCategory> JobCategories { get; set; }
        public DbSet<Subscriptions> Subscriptions { get; set; } 
        public DbSet<JobSeeker> JobSeeker { get; set; }
        public DbSet<Employer> Employer { get; set; }
        public DbSet<Admin> Admin { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure relationships, indexes, etc. here if needed
            // For example:
            // modelBuilder.Entity<User>()
            //    .HasMany(u => u.JobApplications)
            //    .WithOne(ja => ja.JobSeeker)
            //    .HasForeignKey(ja => ja.JobSeekerId);

            // Configure any additional configurations for your entities
        }
    }
}
