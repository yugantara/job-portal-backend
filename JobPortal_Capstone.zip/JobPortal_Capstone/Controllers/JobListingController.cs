﻿using JobPortal_Capstone.IServices;
using JobPortal_Capstone.Models;
using Microsoft.AspNetCore.Mvc;

namespace JobPortal_Capstone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobListingController : ControllerBase
    {
        private readonly IJobListingService _jobListingService;

        public JobListingController(IJobListingService jobListingService)
        {
            _jobListingService = jobListingService;
        }

        [HttpGet]
        public IActionResult GetJobs()
        {
            var jobListings = _jobListingService.GetJobListings();
            return Ok(jobListings);
        }

        [HttpGet("{id}")]
        public IActionResult GetJobById(int id)
        {
            var jobListing = _jobListingService.GetJobById(id);
            if (jobListing == null)
                return NotFound();

            return Ok(jobListing);
        }

        [HttpPost]
        public IActionResult PostJob(JobListings jobListing)
        {
            try
            {
                var createdJobListing = _jobListingService.PostJob(jobListing);
                return CreatedAtAction(nameof(GetJobById), new { id = createdJobListing.Id }, createdJobListing);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateJobDetails(int id, JobListings jobListing)
        {
            jobListing.Id = id;

            try
            {
                _jobListingService.UpdateJobDetails(jobListing);
                return Ok(new { message = "Job details updated successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteJob(int id)
        {
            try
            {
                _jobListingService.DeleteJob(id);
                return Ok(new { message = "Job listing deleted successfully" });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
