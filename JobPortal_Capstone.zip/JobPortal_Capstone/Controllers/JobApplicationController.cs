﻿using JobPortal_Capstone.IServices;
using JobPortal_Capstone.Models;
using JobPortal_Capstone.Services;
using Microsoft.AspNetCore.Mvc;

namespace JobPortal_Capstone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobApplicationController : ControllerBase
    {
        private readonly IJobApplicationService _jobApplicationService;

        public JobApplicationController(IJobApplicationService jobApplicationService)
        {
            _jobApplicationService = jobApplicationService;
        }

        [HttpPost]
        public IActionResult ApplyForJob(JobApplications jobApplication)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); 
            }
                var createdApplication = _jobApplicationService.Apply(jobApplication);
                return CreatedAtAction(nameof(GetJobApplicationById), new { id = createdApplication.Id }, createdApplication);
        }

        [HttpGet("{id}")]
        public IActionResult GetJobApplicationById(int id)
        {
            var jobApplication = _jobApplicationService.GetJobApplicationById(id);
            if (jobApplication == null)
                return NotFound();

            return Ok(jobApplication);
        }

        [HttpGet]
        public IActionResult GetApplications()
        {
            try
            {
                var jobApplications = _jobApplicationService.GetAllJobApplications();
                return Ok(jobApplications);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            _jobApplicationService.DeleteJobApplication(id);
            return Ok("Job application deleted.");
        }
    }
}
