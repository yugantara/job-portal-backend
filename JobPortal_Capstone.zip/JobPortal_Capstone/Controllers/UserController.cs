﻿using JobPortal_Capstone.IServices;
using JobPortal_Capstone.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Text;

namespace JobPortal_Capstone.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult GetAllUsers()
        {
            try
            {
                var users = _userService.GetAllUsers();
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("{id}")]
        public IActionResult GetUserById(int id)
        {

            var user = _userService.GetUserById(id);

            if (user == null)
            {
                return NotFound(); // 404 Not Found
            }

            return Ok(user); // 200 OK with user data
        }

        [HttpGet("username/{username}")]
        public IActionResult GetUserByUsername(string username)
        {
            var user = _userService.GetUserByUsername(username);

            if (user == null)
            {
                return NotFound(); // 404 Not Found
            }

            return Ok(user); // 200 OK with user data
        }

        [HttpPost("Register")]
        public IActionResult RegisterUser(Users user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // 400 Bad Request with validation errors
            }
            try
            {
                var createdUser = _userService.RegisterUser(user);
                return Ok(createdUser); // 200 OK with user data
            }
            catch (Exception ex)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpGet("Login")]
        public IActionResult LoginUser(string username, string password)
        {
            try
            {
                var user = _userService.LoginUser(username, password);
                return Ok(user);
            }
            catch (Exception ex)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id, Users user)
        {
            if (id != user.Id)
            {
                return BadRequest();
            }
            try
            {
                _userService.UpdateUser(user);
                return Ok("User profile updated!");
            }
            catch (Exception ex)
            {
                return this.StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            _userService.DeleteUser(id);
            return Ok("User profile deleted.");
        }
    }
}

